
export default interface WeatherDataObserver {
    notify: (input: any) => void;
}